
// YBMfcView.cpp : CYBMfcView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "YBMfc.h"
#endif

#include "YBMfcDoc.h"
#include "YBMfcView.h"
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CYBMfcView

IMPLEMENT_DYNCREATE(CYBMfcView, CView)

BEGIN_MESSAGE_MAP(CYBMfcView, CView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CYBMfcView ����/����
const int gKEDU = 5;
const int gGap = 200;
CYBMfcView::CYBMfcView()
{
	// TODO: �ڴ˴����ӹ������
	m_iSpeed = 800;
	m_iAlt = 850;
	m_direct = 23;
}

CYBMfcView::~CYBMfcView()
{
}

BOOL CYBMfcView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CView::PreCreateWindow(cs);
}

// CYBMfcView ����

BOOL CYBMfcView::IsValidSpeed(int iSpeed)
{
	if(iSpeed>=40 && iSpeed<=1000)
		return TRUE;
	else 
		return FALSE;
}

BOOL CYBMfcView::IsJiou(int iSpeed,int step)
{
	int s = iSpeed/step;
	return s%2 == 0;
}

BOOL CYBMfcView::IsEndByTen(int iVal)
{
	return iVal%10 == 0;
}

bool CYBMfcView::DrawDirectionStrip(CDC* pDC, int iCurVal, int iYOrg, int left, int right, int step, int iMode)
{
	int kdOffset;
	int labelOffset;
	int endKdOffset;
	int markOffset;
	int gap = 20;
	if(iMode == 0)
	{
		kdOffset = -gKEDU;
		endKdOffset = kdOffset-10;
		labelOffset = 25;
		markOffset = 15;
	}else
	{
		kdOffset = gKEDU;
		endKdOffset = kdOffset+10;
		labelOffset = -5;
		markOffset = -15;
	}
	
	int iXOrg = (left+right)/2;
	pDC->MoveTo(iXOrg,iYOrg);
	/* darw mark triangle*/
	pDC->LineTo(iXOrg-5,iYOrg+markOffset); 
	pDC->LineTo(iXOrg+5,iYOrg+markOffset); 
	pDC->LineTo(iXOrg,iYOrg); 
	
	char strBuf[10];
	itoa(iCurVal,strBuf,10);
	pDC->TextOut(iXOrg-7,iYOrg+labelOffset,strBuf,strnlen(strBuf, _countof(strBuf)));

	int prev =  iCurVal/step*step;
	int nex = prev+step;
	if(prev==0)
		prev = 360;
	int iCurX;

	/* draw right strip*/
	pDC->MoveTo(iXOrg,iYOrg);
	iCurX = iXOrg+(nex-iCurVal)*gap/step;
	pDC->LineTo(iCurX,iYOrg);
	if(IsEndByTen(nex))
	{
		pDC->LineTo(iCurX, iYOrg+kdOffset-5); 
		itoa(nex/10,strBuf,10);
		pDC->TextOut(iCurX-5,iYOrg-labelOffset,strBuf,strnlen(strBuf, _countof(strBuf)));
	}
	else
	{
		pDC->LineTo(iCurX, iYOrg+kdOffset); 
	}
	pDC->MoveTo(iCurX,iYOrg);
	
	nex = nex+step;
	if(nex>360)
		nex = 10;
	while(iCurX<right)
	{
		iCurX = iCurX+gap;
		if(iCurX>right)
		{
			iCurX = right;
			pDC->LineTo(iCurX,iYOrg);
			pDC->LineTo(iCurX,iYOrg+endKdOffset); 
			break;
		}
		pDC->LineTo(iCurX,iYOrg);
		if(IsEndByTen(nex))
		{
			pDC->LineTo(iCurX,iYOrg+kdOffset-5); 
			/* draw lable*/
			itoa(nex/10,strBuf,10);
			pDC->TextOut(iCurX-5,iYOrg-labelOffset,strBuf,strnlen(strBuf, _countof(strBuf)));
		}
		else
		{
			pDC->LineTo(iCurX,iYOrg+kdOffset); 
		}
		pDC->MoveTo(iCurX,iYOrg);
		nex = nex+step;
		if(nex>360)
			nex = 10;
	}
	
	/* draw left strip*/
	iCurX = iXOrg-(iCurVal-prev)*gap/step;
	pDC->MoveTo(iXOrg,iYOrg);
	pDC->LineTo(iCurX,iYOrg);
	if(IsEndByTen(prev))
	{
		pDC->LineTo(iCurX, iYOrg+kdOffset-5); 
		itoa(prev/10,strBuf,10);
		pDC->TextOut(iCurX-5,iYOrg-labelOffset,strBuf,strnlen(strBuf, _countof(strBuf)));
	}
	else
	{
		pDC->LineTo(iCurX, iYOrg+kdOffset); 
	} 

	pDC->MoveTo(iCurX,iYOrg);
	prev = prev - step;
	if(prev==0)
		prev = 360;
	while(iCurX>left)
	{
		iCurX = iCurX-gap;
		if(iCurX<left)
		{
			iCurX = left;
			pDC->LineTo(iCurX,iYOrg);
			pDC->LineTo(iCurX,iYOrg+endKdOffset); 
			break;
		}
		pDC->LineTo(iCurX,iYOrg);
		if(IsEndByTen(prev))
		{
			pDC->LineTo(iCurX, iYOrg+kdOffset-5); 
			itoa(prev/10,strBuf,10);
			pDC->TextOut(iCurX-5,iYOrg-labelOffset,strBuf,strnlen(strBuf, _countof(strBuf)));
		}
		else
		{
			pDC->LineTo(iCurX, iYOrg+kdOffset); 
		}
		pDC->MoveTo(iCurX,iYOrg);
		
		prev = prev-step;
		if(prev==0)
			prev = 360;
	}
	return false;
}

bool CYBMfcView::DrawVerStrip(CDC* pDC, int iCurVal, int iXOrg, int top, int bottom, int step, int iMode)
{
	int kdOffset;
	int labelOffset;
	int endKdOffset;
	int markOffset;
	int gap = 20;
	if(iMode == 0)
	{
		kdOffset = -gKEDU;
		endKdOffset = kdOffset-10;
		labelOffset = 35;
		markOffset = 15;
	}else
	{
		kdOffset = gKEDU;
		endKdOffset = kdOffset+10;
		labelOffset = -5;
		markOffset = -15;
	}
	
	int iYOrg = (top+bottom)/2;
	pDC->MoveTo(iXOrg,iYOrg);
	/* darw mark triangle*/
	pDC->LineTo(iXOrg+markOffset,iYOrg-5); 
	pDC->LineTo(iXOrg+markOffset,iYOrg+5); 
	pDC->LineTo(iXOrg,iYOrg); 
	
	char strBuf[10];
	itoa(iCurVal,strBuf,10);
	pDC->TextOut(iXOrg-labelOffset,iYOrg-7,strBuf,strnlen(strBuf, _countof(strBuf)));

	int prev =  iCurVal/step*step;
	int nex = prev+step;
	int iCurY = iCurVal;

	/* draw downside strip*/
	if(iCurY!=40)
	{
		pDC->MoveTo(iXOrg,iYOrg);
		iCurY = iYOrg+(iCurVal-prev)*gap/step;
		pDC->LineTo(iXOrg,iCurY);
		pDC->LineTo(iXOrg+kdOffset,iCurY); /* draw short line*/
		pDC->MoveTo(iXOrg,iCurY);
		prev = prev - step;
		while(prev>=40 && iCurY<bottom)
		{
			iCurY = iCurY+gap;
			if(iCurY>bottom)
			{
				iCurY = bottom;
				pDC->LineTo(iXOrg,iCurY);
				pDC->LineTo(iXOrg+endKdOffset,iCurY); 
				break;
			}
			pDC->LineTo(iXOrg,iCurY);
			pDC->LineTo(iXOrg+kdOffset,iCurY); 
			pDC->MoveTo(iXOrg,iCurY);
			if(IsJiou(prev,step))
			{
				/* draw lable*/
				itoa(prev,strBuf,10);
				pDC->TextOut(iXOrg-labelOffset,iCurY-7,strBuf,strnlen(strBuf, _countof(strBuf)));
			}
			prev = prev-step;
		}
	}

	/* draw upside strip*/
	iCurY = iYOrg-(nex-iCurVal)*gap/step;
	pDC->MoveTo(iXOrg,iYOrg);
	pDC->LineTo(iXOrg,iCurY);
	pDC->LineTo(iXOrg+kdOffset,iCurY); 

	pDC->MoveTo(iXOrg,iCurY);
	nex = nex + step;
	while(iCurY>top)
	{
		iCurY = iCurY-gap;
		if(iCurY<top)
		{
			iCurY = top;
			pDC->LineTo(iXOrg,iCurY);
			pDC->LineTo(iXOrg+endKdOffset,iCurY); 
			break;
		}
		pDC->LineTo(iXOrg,iCurY);
		pDC->LineTo(iXOrg+kdOffset,iCurY); 
		pDC->MoveTo(iXOrg,iCurY);
		if(IsJiou(nex,step))
		{
			itoa(nex,strBuf,10);
			pDC->TextOut(iXOrg-labelOffset,iCurY-7,strBuf,strnlen(strBuf, _countof(strBuf)));
		}
		nex = nex+step;
	}
	return false;
}

void CYBMfcView::OnDraw(CDC* pDC)
{
	CYBMfcDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	RECT rec;
	GetClientRect(&rec);
	int iWidth = rec.right-rec.left;
	int iHeight = rec.bottom-rec.top;

	int iXOrg = iWidth/2;
	int iYOrg = iHeight/2;

	int top = gGap;
	int bottom = iHeight-gGap;

	int step = 10;

	//if(!IsValidSpeed(m_iSpeed))
	//	return;
	//m_iSpeed = 1200;
	DrawVerStrip(pDC,m_iSpeed ,200, top, bottom, step, 0);
	step = 100;
	DrawVerStrip(pDC,m_iAlt ,600, top, bottom, step, 1);

	DrawDirectionStrip(pDC, m_direct, 100, 200, 600, 5, 0);

	// TODO: �ڴ˴�Ϊ�����������ӻ��ƴ���
}

void CYBMfcView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CYBMfcView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CYBMfcView ���

#ifdef _DEBUG
void CYBMfcView::AssertValid() const
{
	CView::AssertValid();
}

void CYBMfcView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CYBMfcDoc* CYBMfcView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CYBMfcDoc)));
	return (CYBMfcDoc*)m_pDocument;
}
#endif //_DEBUG


// CYBMfcView ��Ϣ��������


void CYBMfcView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	switch(nIDEvent)
	{
	case 1:
		m_iSpeed+=1;
		break;
	case 2:
		m_iAlt += 10;
		break;
	case 3:
		m_direct +=1;
		if(m_direct>360)
			m_direct = 1;
		break;
	}
	Invalidate();
	CView::OnTimer(nIDEvent);
}


void CYBMfcView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: �ڴ�����ר�ô����/����û���
	SetTimer(1,50,NULL);
	SetTimer(2,50,NULL);
	SetTimer(3,50,NULL);
}
